package Main;

public class person {

	String name;
	String email;
	int age;

	public person() { // constructor
		name = "john";
		email = "mesbah@gmail.com";
		age = 25;
	}

	// public void run() {
	// System.out.println("run " + name + ", run");
	// }
	//
	// public void greet() {
	// System.out.println("hello");
	// }
	//
	//// {
	//// System.out.println("Initialize block"); //Initialize block
	//// }
	////
	//// static
	//// {
	//// System.out.println("Static Block"); //Static block
	//// }
	// public void printInfo() {
	// System.out.println("Name: " + name + "\nemail: " + email + "\nage: " +
	// age);
	// }
}
