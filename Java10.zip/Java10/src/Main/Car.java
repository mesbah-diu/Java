package Main;

public class Car {

	String color, model, brand;
	int year, price;

	public Car(String color, String brand, String model) {
		color = this.color;
		this.brand = brand;
		this.model = model;
	}

	public void dbreak() {
		System.out.println("Car brand: " + brand + "\nModel: " + model);
	}

	public void run() {
		System.out.println("Year: " + year + "\nPrice: " + price);
	}

	public void horn() {
		System.out.println("Color: " + color);
	}
}
