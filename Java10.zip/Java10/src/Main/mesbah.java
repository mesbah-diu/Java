package Main;

public class mesbah {

	public static void main(String[] args) {

		// person p1 = new person();
		//
		// person p2 = new person();
		// p2.name = "Don";
		// p2.email = "hulululu@gmail.com";
		// p2.age = 35;

		// p1.greet();
		// p1.run();
		// p1.printInfo();
		//
		// p2.greet();
		// p2.run();
		// p2.printInfo();
		//
		Car c = new Car("Black", "Audi", "R8");

		c.price = 100000;
		c.year = 2008;

		c.dbreak();
		c.run();
		c.horn();

	}

}
